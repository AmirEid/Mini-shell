/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirect.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void restore_input(int saved_stdin)
{
	dup2(saved_stdin, STDIN_FILENO);
	close(saved_stdin);
	return;
}

void restore_output(int saved_stdout)
{
	dup2(saved_stdout, STDOUT_FILENO);
	close(saved_stdout);
	return;
}

int redirect_output(t_word *word_list)
{
	int saved_stdout;
	int fd;

	saved_stdout = dup(STDOUT_FILENO);
	while (word_list != NULL)
	{
		if (ft_strcmp(word_list->type, "redirect") == 0)
		{
			if (ft_strcmp(word_list->value, ">") == 0)
			{
				if (word_list->next == NULL)
				{
					ft_putstr_fd("syntax error\n", 2);
					global_exit = 2;
					restore_output(saved_stdout);
					return (-1);
				}
				word_list = word_list->next;
				fd = open(word_list->value, O_WRONLY | O_CREAT | O_TRUNC, 0666);
        		if (fd < 0)
       		 	{
					ft_putstr_fd("open file error\n", 2);
					global_exit = 1;
					restore_output(saved_stdout);
          			return (-1);
        		}
				dup2(fd, STDOUT_FILENO);
				close(fd);
			}
			else if (ft_strcmp(word_list->value, ">>") == 0)
			{
				if (word_list->next == NULL)
				{
					ft_putstr_fd("syntax error\n", 2);
					global_exit = 2;
					restore_output(saved_stdout);
					return (-1);
				}
				word_list = word_list->next;
				fd = open(word_list->value, O_WRONLY | O_CREAT | O_APPEND, 0666);
        		if (fd < 0)
        		{
					ft_putstr_fd("open file error\n", 2);
					global_exit = 1;
					restore_output(saved_stdout);
          			return (-1);
        		}
				dup2(fd, STDOUT_FILENO);
				close(fd);
			}
		}
		word_list = word_list->next;
	}
	return(saved_stdout);
}

int redirect_input(t_word *word_list)
{
	int saved_stdin;
	int fd;
	int pipe_fd[2];
	char buffer[4096];
	char temp_buffer[4096];
	int count_read;

	saved_stdin = dup(STDIN_FILENO);
	while (word_list != NULL)
    {
        if (ft_strcmp(word_list->type, "redirect") == 0 && ft_strcmp(word_list->value, "<") == 0)
        {
            if (word_list->next == NULL)
            {
				ft_putstr_fd("syntax error\n", 2);
				global_exit = 2;
				restore_input(saved_stdin);
				return (-1);
            }
            word_list = word_list->next;
            fd = open(word_list->value, O_RDONLY);
            if (fd < 0)
            {
				ft_putstr_fd("open file error\n", 2);
				global_exit = 1;
				restore_input(saved_stdin);
          		return (-1);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
        }
		else if (ft_strcmp(word_list->type, "redirect") == 0 && ft_strcmp(word_list->value, "<<") == 0)
        {
			if (word_list->next == NULL)
            {
				ft_putstr_fd("syntax error\n", 2);
				global_exit = 2;
				restore_input(saved_stdin);
				return (-1);
            }
            word_list = word_list->next;
			dup2(saved_stdin, STDIN_FILENO);
			if (pipe(pipe_fd) == -1)
			{
				ft_putstr_fd("pipe error\n", 2);
				global_exit = 1;
				restore_input(saved_stdin);
        		return (-1);
    		}
			while (1)
			{
				write(STDOUT_FILENO, "> ", 2);
        		count_read = read(STDIN_FILENO, buffer, sizeof(buffer));
				if (count_read < 0)
        		{
            		ft_putstr_fd("read error\n", 2);
                    close(pipe_fd[0]);
                    close(pipe_fd[1]);
					global_exit = 1;
					restore_input(saved_stdin);
                    return -1;
        		}
				if (count_read == 0)
				{
					close(pipe_fd[1]);
					close(pipe_fd[0]);
					restore_input(saved_stdin);
					return (-2);
				}
				buffer[count_read] = '\0';
				ft_strlcpy(temp_buffer, buffer, count_read + 1);
				if (temp_buffer[count_read - 1] == '\n')
        			temp_buffer[count_read - 1] = '\0';
				if (ft_strcmp(temp_buffer, word_list->value) == 0)
					break;
        		write(pipe_fd[1], buffer, count_read);
            }
			close(pipe_fd[1]);
			dup2(pipe_fd[0], STDIN_FILENO);
            close(pipe_fd[0]);
        }
        word_list = word_list->next;
    }
    return(saved_stdin);
}

//old version
/* 
int redirect_input(t_word *word_list)
{
	int saved_stdin;
	int fd;
	int	buffer_size = 1024;
	int	count_read;
    char buffer[1024];
	char temp_buffer[1024];

	count_read = 0;
	saved_stdin = dup(STDIN_FILENO);
	while (word_list != NULL)
    {
        if (ft_strcmp(word_list->type, "redirect") == 0 && ft_strcmp(word_list->value, "<") == 0)
        {
            if (word_list->next == NULL)
            {
                perror("syntax error");
                return (-1);
            }
            word_list = word_list->next;
            fd = open(word_list->value, O_RDONLY);
            if (fd < 0)
            {
                perror("open");
                return (-1);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
        }
		else if (ft_strcmp(word_list->type, "redirect") == 0 && ft_strcmp(word_list->value, "<<") == 0)
        {
			if (word_list->next == NULL)
            {
                perror("syntax error");
                return (-1);
            }
            word_list = word_list->next;
            fd = open("tmpfile", O_TRUNC | O_CREAT | O_WRONLY, 0777);
            if (fd < 0)
            {
                perror("open");
                return (-1);
            }	
			while (1)
			{
				write(STDOUT_FILENO, "> ", 2);
				count_read = read(STDIN_FILENO, buffer, buffer_size);
				if (count_read <= 0)
				{
                	if (count_read == 0)
						return (-1); // Esce dal loop se l'utente invia EOF (Ctrl+D)
					perror("read");
                    close(fd);
                	return (-1);
            	}
				buffer[count_read] = '\0';
				ft_strlcpy(temp_buffer, buffer, count_read + 1);
				if (temp_buffer[count_read - 1] == '\n')
        			temp_buffer[count_read - 1] = '\0';
				if (ft_strcmp(temp_buffer, word_list->value) == 0)
					break;
				write(fd, buffer, count_read);
            }
            close(fd);
    		fd = open("tmpfile", O_RDONLY);
    		if (fd < 0)
    		{
        		perror("open");
        		return (-1);
    		}
			dup2(fd, STDIN_FILENO);
            close(fd);
        }
        word_list = word_list->next;
    }
    return(saved_stdin);
}*/
