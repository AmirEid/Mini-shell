/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell_redirect.h                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 11:45:34 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 11:45:41 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_REDIRECT_H
# define MINISHELL_REDIRECT_H

int     redirect_output(t_word *word_list);
void    restore_output(int saved_stdout);
int     redirect_input(t_word *word_list);
void    restore_input(int saved_stdin);

#endif
