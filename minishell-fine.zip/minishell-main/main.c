/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/06/14 17:39:14 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	global_exit = 0;

void print_command_strings(char **command) {
    if (command == NULL) {
        printf("Il comando è NULL.\n");
        return;
    }

    int i = 0;
    while (command[i] != NULL) {
        printf("Comando %d: %s\n", i, command[i]);
        i++;
    }
}

int main(int argc, char **argv, char **env_sys) {
    char *input;
    char prompt[PATH_MAX] = "";
    t_env_var *env;
    t_word *word_list;
    char **command;
    int i;

    init_value(&env, env_sys, prompt);
    (void)argc;
    (void)argv;
    while (1)
    {
        input = readline(prompt);
        if (input == NULL)
            exit_one(input, &env);

        // Controlla se l'input contiene una pipe
        if (ft_strchr_pipe(input, '|') != NULL)
		{
            if(is_valid_pipe_syntax(input) < 0)
            {
                ft_putstr_fd("Syntax error\n", 2);
                global_exit = 2;
                //rl_on_new_line();
                free(input);
                continue;
            }
            command = ft_divide_pipe(input);

            //print_command_strings(command); //debug
            /*
            if (pipe_syntax_error(command) < 0)
            {
                clean_string(command);
                //rl_on_new_line();
                free(input);
                continue;
            }
            */
            int prev_fd = STDIN_FILENO;
            i = 0;
            int status;

            while (command[i] != NULL)
			{
                word_list = create_list(&word_list, command[i], env);
                if (word_list == NULL)
                    exit_two(input, &env);

                int fd[2];
                int pid;

                pipe(fd);
                pid = fork();
                if (pid == -1)
                {
                    ft_putstr_fd("fork failed\n", 2);
                    //exit(1);
                }
                if (pid == 0)
				{
                    // Processo figlio
                    close(fd[0]);
                    if (i > 0)
					{
                        dup2(prev_fd, STDIN_FILENO);
                        close(prev_fd);
                    }
                    if (command[i + 1] != NULL)
					{
                        dup2(fd[1], STDOUT_FILENO);
                        close(fd[1]);
                    }
					analyze_command(word_list, prompt, &env);
                    if (global_exit != 0)
                    {
                        close(fd[1]);
                        exit(global_exit);
                    }
                    else
                    {
                        close(fd[1]);
                        exit(0);
                    }
                }
				else
				{
                    // Processo genitore
                    close(fd[1]);
                    waitpid(pid, &status, 0);
                    if (WIFEXITED(status) != 0 && WEXITSTATUS(status) != 0)
                    {
                        global_exit = WEXITSTATUS(status);
                        if (global_exit == 2)
                            break;
                        //break;
                    }
                    else
                        global_exit = 0;
                    if (i > 0)
					{
                        close(prev_fd);
                    }
                    prev_fd = fd[0];
                }
                clean_list(&word_list);
                i++;
            }
            if (prev_fd != STDIN_FILENO)
                close(prev_fd);
            clean_string(command);
        }
		else
		{
            // Gestione del comando singolo
            word_list = create_list(&word_list, input, env);
            if (word_list == NULL)
                exit_two(input, &env);

            //print_list(word_list); //debug

            if (analyze_command(word_list, prompt, &env) == -1)
                exit_three(input, &env, &word_list);
            clean_list(&word_list);
        }
        rl_on_new_line();
        add_history(input);
        free(input);
    }
    return (global_exit);
}
