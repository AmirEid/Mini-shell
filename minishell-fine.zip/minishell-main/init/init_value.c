/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_value.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void handle_sigint(int sig) 
{
    (void)sig;
    write(STDOUT_FILENO, "\n", 1);
    rl_on_new_line();
	rl_replace_line("", 0);
    rl_redisplay();
}

void handle_sigquit(int sig) 
{
	//struct termios	term;

	(void)sig;
	/*
	tcgetattr(STDIN_FILENO, &term);
	term.c_lflag &= ~ECHOCTL;
	tcsetattr(STDIN_FILENO, TCSANOW, &term);
	*/
}

void	init_value(t_env_var **env, char **env_sys, char *prompt)
{
	char cwd[PATH_MAX] = "";

	*env = NULL;
	init_env(env, env_sys);
	//add_global_exit(env);
	if (getcwd(cwd, sizeof(cwd)) != NULL)
	{
		ft_strlcat(prompt, cwd, sizeof(cwd));
		ft_strlcat(prompt, "$ ", sizeof(cwd));
	}
	signal(SIGINT, handle_sigint);
	signal(SIGQUIT, handle_sigquit);
	return;
}
