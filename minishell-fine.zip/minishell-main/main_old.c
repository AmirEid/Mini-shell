/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/06/14 17:39:14 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	global_exit = 0;

/* main con pipe

int	main(int argc, char **argv, char **env_sys)
{
	char *input;
	char prompt[PATH_MAX] = "";
	t_env_var *env;
	t_word *word_list;

	char **command;
	int i;
	
	init_value(&env, env_sys, prompt);
	(void)argc;
	(void)argv;
	while (1)
	{
		input = readline(prompt);
		if (input == NULL)
			exit_one(input, &env);

		command = ft_split(input, '|');
		int prev_fd = STDIN_FILENO;
		i = 0; // Inizializza i

		while(command[i] != NULL)
		{
			word_list = create_list(&word_list, command[i], env);
			if (word_list == NULL)
				exit_two(input, &env);

			int fd[2];
			int pid;

			pipe(fd);
			pid = fork();
			if (pid == -1)
            {
                perror("fork");
                //exit(EXIT_FAILURE);
            }
			if (pid == 0)
			{
				// Processo figlio
				close(fd[0]);
				if (i > 0) // Se non è il primo comando
				{
					dup2(prev_fd, STDIN_FILENO); // Reindirizza stdin dal precedente comando
					close(prev_fd);
				}
				if (command[i + 1] != NULL) // Se non è l'ultimo comando
				{
					dup2(fd[1], STDOUT_FILENO); // Reindirizza stdout alla fine di scrittura della pipe
					close(fd[1]);
				}
				if (analyze_command(word_list, prompt, &env) == -1)
					exit_three(input, &env, &word_list);
				close(fd[1]);
				exit(0);
			}
			else
			{
				close(fd[1]); // Nel genitore, chiude il lato di scrittura della pipe
				waitpid(pid, NULL, 0); // Aspetta che il figlio termini
				if (i > 0)
				{
					close(prev_fd); // Chiude il fd del precedente comando
				}
				// Leggi da fd[0] per ottenere l'output del figlio
				prev_fd = fd[0];
			}

			clean_list(&word_list);
			i++;
		}

		if (prev_fd != STDIN_FILENO)
			close(prev_fd);

		rl_on_new_line();
		add_history(input);
		free(input);

		// Libera la memoria allocata per command
		for (i = 0; command[i] != NULL; i++)
			free(command[i]);
		free(command);
	}
	return (0);
}
*/

//main comando singolo

int	main(int argc, char **argv, char **env_sys)
{
	char *input;
	char prompt[PATH_MAX] = "";
	//char **s;
	t_env_var *env;
	t_word *word_list;
	
	init_value(&env, env_sys, prompt);
	(void)argc;
	(void)argv;
	while (1)
	{
		input = readline(prompt);
		if (input == NULL)
			exit_one(input, &env);
		//s = split_string(input, env);
		//if (s == NULL)
		//	exit_one(input, &env);
		word_list = create_list(&word_list, input, env);
		if (word_list == NULL)
			exit_two(input, &env);

		print_list(word_list); //debug

		if (analyze_command(word_list, prompt, &env) == -1)
			exit_three(input, &env, &word_list);
		clean_list(&word_list);
		rl_on_new_line();
		add_history(input);
		free(input);
	}
	//rl_clear_history();
	return (global_exit);
}