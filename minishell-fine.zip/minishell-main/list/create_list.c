/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_list.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void	print_list(t_word *word_list)
{
	t_word *temp;

	temp = word_list;
	while (temp != NULL)
	{
		printf("type: %s\n", temp->type);
		printf("value: %s\n", temp->value);
		temp = temp->next;
	}
	return;
}

void    assign_type(char *s, t_word *new, t_word *prev, int *command)
{
    if (ft_strcmp(s, ">") == 0 || ft_strcmp(s, ">>") == 0 || ft_strcmp(s, "<") == 0 || ft_strcmp(s, "<<") == 0)
        new->type = "redirect";
    else if (prev != NULL && (ft_strcmp(prev->type, "redirect") == 0))
        new->type = "file";
    else if (*command == 0)
    {
        new->type = "command";
        *command = 1;
    }
    else
        new->type = "argument";
    return;
}

t_word  *create_node(char *s, t_word *prev, int *command)
{
    t_word *new;

    new = (t_word *)malloc(sizeof(t_word));
    if (new == NULL)
        return(NULL);
    assign_type(s, new, prev, command);
    new->value = ft_strdup(s);
    if (new->value == NULL)
    {
        free(new);
        return(NULL);
    }
    new->next = NULL;
    return(new);
}
/*
t_word  *create_node_first(char *s)
{
    t_word *new;

    new = (t_word *)malloc(sizeof(t_word));
    if (new == NULL)
        return(NULL);
    new->type = "command";
    new->value = ft_strdup(s);
    if (new->value == NULL)
    {
        free(new);
        return(NULL);
    }
    new->next = NULL;
    return(new);
}*/

static t_word   *error_exit(t_word **word_list)
{
    clean_list(word_list);
    return(NULL);
}

static t_word   *empty_input(char **s)
{
    t_word *new;

    new = (t_word *)malloc(sizeof(t_word));
    if (new == NULL)
        return(NULL);
    new->type = "argument";
    new->value = ft_strdup("");
    new->next = NULL;
    clean_string(s);
    return(new);
}

t_word  *create_list(t_word **word_list, char *input, t_env_var *env)
{
    int i;
    t_word *temp;
    t_word *new;
    t_word *prev;
    int command;
    char **s;

    s = split_string(input, env);
    if (s == NULL)
        return(NULL);
    if (s[0] == NULL)
        return(*word_list = empty_input(s));
    command = 0;
    i = 0;
    prev = NULL;
    *word_list = create_node(s[i], NULL, &command);
    if (*word_list == NULL)
        return(error_exit(word_list));
    i++;
    temp = *word_list;
    while (s[i] != NULL)
    {
        prev = temp;
        new = create_node(s[i], prev, &command);
        if (new == NULL)
            return(error_exit(word_list));
        temp->next = new;
        temp = new;
        i++;
    }
    clean_string(s);
    return(*word_list);
}