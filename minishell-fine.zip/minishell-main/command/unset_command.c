/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   unset_command.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int	search_valid_env(char *s)
{
	int	i;

	i = 0;
	while (s[i] != '\0' && s[i] != '=')
	{
		if (ft_isenvvar(s[i]) == 0)
			return (-1);
		i++;
	}
	return (0);
}

static void	free_env_var(t_env_var *temp)
{
	free(temp->name);
	free(temp->value);
	free(temp);
}

static void	ft_env_rem(t_env_var **env, char *s1)
{
	t_env_var	*temp;
	t_env_var	*prev;

	temp = *env;
	prev = NULL;
	while (temp != NULL)
	{
		if (ft_strcmp(temp->name, s1) == 0)
		{
			if (prev == NULL)
				*env = temp->next;
			else
				prev->next = temp->next;
			free_env_var(temp);
			return ;
		}
		prev = temp;
		temp = temp->next;
	}
	return ;
}

void	unset_command(t_word *word_list, t_env_var **env)
{
	if (word_list->next != NULL)
	{
		word_list = word_list->next;
		if (ft_strcmp(word_list->type, "argument") != 0)
		{
			ft_putstr_fd("unset: syntax error", 2);
			return ;
		}
	}
	while (word_list != NULL)
	{
		if ((search_valid_env(word_list->value) == 0) && (ft_strcmp(word_list->type, "argument") == 0))
			ft_env_rem(env, word_list->value);
		else
			ft_putstr_fd("Error: invalid env var\n", 2);
		word_list = word_list->next;
	}
	return ;
}
