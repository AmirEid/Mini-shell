/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   other_command.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

char	**assign_argv(t_word *word_list, char *path)
{
	int		i;
	t_word	*temp;
	char	**argv;
	int		z;

	i = 0;
	z = 0;
	temp = word_list;
	while (temp != NULL)
	{
		if (ft_strcmp(temp->type, "argument") == 0)
			z++;
		temp = temp->next;
		i++;
	}
	argv = (char **)malloc(sizeof(char *) * (z + 2));
	if (argv == NULL)
		return (NULL);
	argv[0] = ft_strdup(path);
	if (argv[0] == NULL)
		return (NULL);
	i = 1;
	temp = word_list;
	while (temp != NULL)
	{
		if (ft_strcmp(temp->type, "argument") == 0)
		{
			argv[i] = ft_strdup(temp->value);
			if (argv[i] == NULL)
				return (free_string(argv, i));
			i++;
		}
		temp = temp->next;
	}
	argv[i] = NULL;
	return (argv);
}

int other_error(void)
{
	ft_putstr_fd("malloc failed\n", 2);
	global_exit = 1;
	return (-1);
}

int	is_executable(t_word *word_list)
{
	char	path[PATH_MAX] = "";
	pid_t	pid;
	char	**argv;

	ft_strlcat(path, word_list->value, sizeof(path));
	if (access(path, X_OK) == 0)
	{
		pid = fork();
		if (pid == 0)
		{
			argv = assign_argv(word_list, path);
			//char *argv[] = {path, NULL};
			execve(path, argv, NULL);
			perror("execve error");
			clean_string(argv);
			return (0);
		}
		else if (pid > 0)
		{
			waitpid(pid, NULL, 0);
			return (0);
		}
		else
		{
			perror("fork error");
			return (0);
		}
	}
	return (1);
}

int other_command(t_word *word_list, t_env_var *env)
{
	char **prog;
	char path[PATH_MAX] = "";
	pid_t pid;
	int i = 0;
	char **argv;

	if (is_executable(word_list) == 0)
		return (0);
	prog = NULL;
	while (env != NULL)
	{
		if (ft_strcmp(env->name, "PATH") == 0)
		{
			prog = ft_split(env->value, ':');
			if (prog == NULL)
				return (other_error());
		}
		env = env->next;
	}
	if (prog == NULL)
	{
		ft_putstr_fd("command not found\n", 2);
		global_exit = 2;
		return (0);
	}
	while (prog[i] != NULL)
	{
		ft_memset(path, '\0', sizeof(path));
		ft_strlcat(path, prog[i], sizeof(path));
		ft_strlcat(path, "/", sizeof(path));
		ft_strlcat(path, word_list->value, sizeof(path));
		if (access(path, X_OK) == 0)
		{
			pid = fork();
			if (pid == 0)
			{
				argv = assign_argv(word_list, path);
				execve(path, argv, NULL); //debug
				ft_putstr_fd("error: Execve error\n", 2);
				global_exit = 13;
				clean_string(argv);
				clean_string(prog);
				return (0);
			}
			else if (pid > 0)
			{
				waitpid(pid, NULL, 0);
				clean_string(prog);
				return (0);
			}
			else
			{
				ft_putstr_fd("fork error\n", 2);
				global_exit = 11;
				clean_string(prog);
				return (0);
			}
		}
		i++;
	}
	clean_string(prog);
	ft_putstr_fd("command not found\n", 2);
	global_exit = 127;
	return (0);
}
