/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell_command.h                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 11:45:34 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 11:45:41 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_COMMAND_H
# define MINISHELL_COMMAND_H

int		analyze_command(t_word *word_list, char *prompt, t_env_var **env);

int		echo_command(t_word *word_list);

int		cd_command(t_word *word_list, char *prompt, t_env_var **env);

int		pwd_command(void);

int		export_command(t_word *word_list, t_env_var **t_env_var);
int		search_already(t_env_var **env, char *s1, char *s2);
int		search_valid_env(char *s);
int		export_env(t_word *temp, t_env_var **env, int append);
int		ft_env_add(t_env_var **env, char *s1, char *s2, int visible);
void	ft_env_print_ex(t_env_var **env);
int		search_operator(t_word *word_list);

void	unset_command(t_word *word_list, t_env_var **env);

void	env_command(t_word *word_list, t_env_var *env);

int		other_command(t_word *word_list, t_env_var *env);
int		is_executable(t_word *word_list);

#endif