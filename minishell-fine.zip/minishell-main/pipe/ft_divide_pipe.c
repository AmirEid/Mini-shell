/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_divide_pipe.c                                 :+:      :+:    :+:     */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/22 18:17:35 by nspinell          #+#    #+#             */
/*   Updated: 2023/12/22 18:17:39 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

// Funzione ausiliaria per contare le parti separate da pipe
int count_parts(const char *s)
{
    int n = 0;
    int in_quotes = 0; // Stato delle virgolette
    int in_single_quotes = 0; // Stato degli apici

    while (*s)
    {
        if (*s == '"') // Inverti lo stato delle virgolette
        {
            in_quotes = !in_quotes;
        }
        else if (*s == '\'') // Inverti lo stato degli apici
        {
            in_single_quotes = !in_single_quotes;
        }
        else if (*s == '|' && !in_quotes && !in_single_quotes) // Conta solo i pipe che non sono all'interno delle virgolette o degli apici
        {
            n++;
        }
        s++;
    }
    return (n + 1); // +1 per l'ultima parte dopo l'ultimo pipe
}
static char	**free_mem(char	**dest, size_t	j)
{
	size_t	i;

	i = 0;
	while (i <= j)
	{
		free(dest[i]);
		i++;
	}
	free(dest);
	return (NULL);
}

// Funzione principale per dividere la stringa
char **ft_divide_pipe(const char *s)
{
    int parts = count_parts(s);
    char **result = malloc((parts + 1) * sizeof(char *));
    if (result == NULL) return NULL;

    const char *start = s;
    int i = 0, in_quotes = 0, in_single_quotes = 0;

    while (*s)
    {
        if (*s == '"')
        {
            in_quotes = !in_quotes;
        }
        else if (*s == '\'')
        {
            in_single_quotes = !in_single_quotes;
        }
        if ((*s == '|' && !in_quotes && !in_single_quotes) || *(s + 1) == '\0')
        {
            const char *end = (*s == '|' && !in_quotes && !in_single_quotes) ? s : s + 1;
            int length = end - start;
            result[i] = malloc(length + 1); // +1 per '\0'
            if (result[i] == NULL)
            {
                free_mem(result, i);
                return NULL;
            }
            ft_strlcpy(result[i], start, length + 1);
            i++;
            start = s + 1;
        }
        s++;
    }
    result[parts] = NULL; // Terminatore dell'array
    return result;
}

/*
int	main()
{
	char const *par = " ciao alla ciccia bu bua vv";
	char c = ' ';
	char **result = ft_split(par, c);
	size_t  i = 0;
    
    printf ("num parole: %zu\n", count_word(par, c));
	printf ("punt par: %s\n", point_word(par, c, 4));
	printf ("lungh par: %zu\n", long_word(par, c, 3));
	printf ("\n");
	printf ("\n");
	while (i < count_word(par, c))
	{
	    printf ("%s", result[i]);
	    printf ("\n%zu\n", i);
	    i++;
	}
	return (0);
}*/
