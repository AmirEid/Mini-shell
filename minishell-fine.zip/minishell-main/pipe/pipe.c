/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipe.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/06/14 17:39:14 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int is_valid_pipe_syntax(char *input)
{
    int validchar;
    int i;
    int j;

    i = 0;
    if (input[0] == '|' || input[ft_strlen(input) - 1] == '|')
    {
        return (-1);
    }
    while (input[i] != '\0')
    {
        if (input[i] == '|')
        {
            validchar = 0;
            j = i + 1;
            while (input[j] != '|' && input[j] != '\0')
            {
                if (ft_isalnum(input[j]) != 0 || input[j] == 34 || input[j] == 39) // Controlla se c'è almeno un carattere alfanumerico
                {
                    validchar = 1;
                    break;
                }
                j++;
            }
            if (validchar == 0)
            {
                return (-1);
            }
            i = j; // Continua la verifica dal carattere successivo
        }
        else
        {
            i++;
        }
    }
    return (0);
}

int pipe_syntax_error(char **command)
{
    int i;

    i = 0;
    while (command[i] != NULL)
    {
        if (command[i][0] == '\0')
        { 
            ft_putstr_fd("Syntax error\n", 2);
            global_exit = 2;
            return (-1);
        }
        i++;
    }
    return (0);
}
