/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell_pipe.h                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 11:45:34 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 11:45:41 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_PIPE_H
# define MINISHELL_PIPE_H

int pipe_syntax_error(char **command);
int is_valid_pipe_syntax(char *input);
char **ft_divide_pipe(const char *s);

#endif
