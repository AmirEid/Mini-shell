/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exit.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

void	exit_one(char *input, t_env_var **env)
{
	free(input);
	clean_env_var(env);
	global_exit = 0;
	exit(global_exit);
	return ;
}

void	exit_two(char *input, t_env_var **env)
{
	free(input);
	clean_env_var(env);
	global_exit = 1;
	ft_putstr_fd("Error: malloc failed or quote error\n", 2);
	exit(global_exit);
	return ;
}

void	exit_three(char *input, t_env_var **env, t_word **word_list)
{
	free(input);
	clean_env_var(env);
	clean_list(word_list);
	global_exit = 1;
	exit(global_exit);
	return ;
}