/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell_clean.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 11:45:34 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 11:45:41 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_CLEAN_H
# define MINISHELL_CLEAN_H

void	clean_string(char **s);
void	clean_list(t_word **word_list);
void	clean_env_var(t_env_var **env);

void	exit_one(char *input, t_env_var **env);
void	exit_two(char *input, t_env_var **env);
void	exit_three(char *input, t_env_var **env, t_word **word_list);

#endif
