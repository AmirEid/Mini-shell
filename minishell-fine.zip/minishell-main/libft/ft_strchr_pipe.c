/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr_pipe.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/18 12:35:30 by nspinell          #+#    #+#             */
/*   Updated: 2023/12/18 12:35:33 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char *ft_strchr_pipe(const char *s, int c)
{
	int	i;

	i = 0;
	while (s[i] != '\0')
	{
		if (s[i] == 34)
		{
			i++;
			while (s[i] != '\0' && s[i] != 34)
				i++;
			if (s[i] == '\0')
				return (NULL);
		}
		if (s[i] == 39)
		{
			i++;
			while (s[i] != '\0' && s[i] != 39)
				i++;
			if (s[i] == '\0')
				return (NULL);
		}
		if (s[i] == (char)c)
		{
			return ((char *)&s[i]);
		}
		i++;
	}
	if (s[i] == '\0' && (char)c == '\0')
	{
		return ((char *)&s[i]);
	}
	return (NULL);
}
