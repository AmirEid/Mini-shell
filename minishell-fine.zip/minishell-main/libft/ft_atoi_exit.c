/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_exit.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/18 14:12:33 by nspinell          #+#    #+#             */
/*   Updated: 2023/12/18 14:12:37 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	numeric_arg(const char *str)
{
	int i;

	i = 0;
	while(str[i] != '\0')
	{
		if (ft_isdigit(str[i]) == 0 && str[i] != 43 && str[i] != 45)
			return (0);
		i++;
	}
	return (1);
}

int	ft_atoi_exit(const char *str)
{
	int	i;
	int	c;
	int	r;

	i = 0;
	c = 0;
	r = 0;
	if (numeric_arg(str) == 0)
	{
		ft_putstr_fd("Error: numeric argument required\n", 2);
		return (2);
	}
	while (str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
	{
		i++;
	}
	if (str[i] == 43 || str[i] == 45)
	{
		if (str[i] == 45)
			c = 1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		r = r * 10 + (str[i] - 48);
		i++;
	}
	if (c == 1)
		r = -r;
	return (r);
}

/*
int	main()
{
	char *s = "255";
	printf(" %d", ft_atoi_exit(s));
	return(0);
}*/