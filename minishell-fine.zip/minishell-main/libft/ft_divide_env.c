/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_divide_env.c                                  :+:      :+:    :+:     */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/12/22 18:17:35 by nspinell          #+#    #+#             */
/*   Updated: 2023/12/22 18:17:39 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static size_t	count_word(char const *s)
{
	size_t	i;

	i = 0;
	while (s[i] != '\0')
	{
		while (s[i] != '=' && s[i] != '\0')
			i++;
		if (s[i] == '\0')
			return(1);
		else
			return(2);
	}
	return (0);
}

static size_t	long_word(char const *s, size_t n)
{
	size_t	i;
	size_t	j;

	i = 0;
	j = 0;
	if (n == 1)
	{
		while (s[i] != '=' && s[i] != '\0')
			i++;
		return (i);
	}
	else if (n == 2)
	{
		while (s[i] != '=' && s[i] != '\0')
			i++;
		if (s[i] == '\0')
			return (0);
		i++;
		while (s[i] != '\0')
		{
			i++;
			j++;
		}
		return (j);
	}
	else
		return (0);
}

static char	*point_word(char const *s, size_t n)
{
	size_t	i;

	i = 0;
	if (n == 1)
		return ((char *)&s[i]);
	else if (n == 2)
	{
		while (s[i] != '=' && s[i] != '\0')
			i++;
		if (s[i] == '\0')
			return ((char *)&s[i]);
		i++;
		return ((char *)&s[i]);
	}
	return ((char *)&s[i]);
}

static char	**free_mem(char	**dest, size_t	j)
{
	size_t	i;

	i = 0;
	while (i <= j)
	{
		free(dest[i]);
		i++;
	}
	free(dest);
	return (NULL);
}

char	**ft_divide_env(char const *s)
{
	size_t	i;
	size_t	j;
	size_t	z;
	char	**dest;

	i = 0;
	j = count_word(s);
	dest = (char **)malloc((j + 1) * sizeof(char *));
	if (dest == NULL)
		return (NULL);
	while (i < j)
	{
		z = 0;
		dest[i] = (char *)malloc(long_word(s, i + 1) + 1);
		if (dest[i] == NULL)
			return (free_mem(dest, i));
		z = 0;
		while(z < long_word(s, i + 1))
		{
			dest[i][z] = point_word(s, i + 1)[z];
			z++;
		}
		dest[i][z] = '\0';
		i++;
	}
	dest[i] = NULL;
	return (dest);
}

/*
int	main()
{
	printf ("inizio\n");
	char const *par = "ciao";
	char **result = ft_divide_env(par);
	size_t  i = 0;

    printf ("num parole: %zu\n", count_word(par));
	printf ("punt par: %s\n", point_word(par, 1));
	printf ("lungh par: %zu\n", long_word(par, 1));
	printf ("\n");
	printf ("\n");
	
	while (i < count_word(par))
	{
	    printf ("%s", result[i]);
	    printf ("\n%zu\n", i);
	    i++;
	}
	//printf ("ciao");
	return (0);
}*/
