/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sub_env_var.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/06/14 18:11:07 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int search_env_var(const char *s, t_env_var *env)
{
    int i;
    char *c;
    int z;

    i = 0;

    if (s[i] == 63)
        return(ft_numlen(global_exit) - 1);
    //printf("s = %s\n", s); //debug
    //fflush(stdout);         //debug
    while (ft_isenvvar(s[i]) == 1)
    {
        i++;
    }

    //printf("i = %d\n", i); //debug
    //fflush(stdout);         //debug

    c = (char *)malloc((i + 1) * sizeof(char));
    if (c == NULL)
        return(-1);
    copy_string(c, s, i);
    while (env != NULL)
    {
        if (ft_strcmp(c, env->name) == 0)
        {
            //z = ft_strlen(env->value) - ft_strlen(c) - 1;
            z = ft_strlen(env->value);
            free(c);
            return(z);
        }
        env = env->next;
    }
    free(c);
    return(0);
}

int count_env_var(const char *s, t_env_var *env)
{
    int i;
    int k;
    int z;
    int res;
    int increment;

    i = 0;
    k = 0;
    z = 0;
    res = 0;
    increment = 0;
    while (s[i] != '\0')
    {
        increment = 0;
        if (s[i] == 36)
        {
            i++;
            increment = 1;
            res = search_env_var(s + i, env);
            z = z + res;
            if (res == -1)
                return(-1);
            while (ft_isenvvar(s[i]) == 1)
            {
                i++;
            }
        }
        if (increment == 0 && s[i] != '\0')
            i++;
        k++;
    }
    return(k + z);
}

char *sub_env_var(char *s, t_env_var *env)
{
    int i;
    int z;

    i = 0;
    z = 0;
    while (s[i] != '\0')
    {
        if (s[i] == 39)
        {
           while (s[i] != 39)
                i++;
        }
        else if (s[i] == '$' && s[i + 1] != '\0' && (s[i + 1] == '$' || ft_isenvvar(s[i + 1]) == 1 || s[i + 1] == '?'))
        {
            z = count_env_var(s, env);
            if (z == -1)
                return(NULL);
            return(new_string(s, z, env));
        }
        else if (s[i] == '$' && ft_isenvvar(s[i + 1]) == 0)
        {
            return(s);
        }
        //aggiungere casi
    i++;
    }
    return(NULL);
}
