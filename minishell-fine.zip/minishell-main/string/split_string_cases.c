/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   split_string.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/06/14 17:43:21 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

char *grate(const char *s, int *i)
{
    char *word;
    int j;

    j = *i;
    if (s[j + 1] !='\0' && s[j + 1] == 62)
    {
        j++;
    }
    j++;
    word = (char *)malloc((j - *i + 1) * sizeof(char));
    if (word == NULL)
        return(NULL);
    copy_string(word, s + *i, j - *i);
    *i = j;
    return(word);
}

char *less(const char *s, int *i)
{
    char *word;
    int j;

    j = *i;
    if (s[j + 1] !='\0' && s[j + 1] == 60)
    {
        j++;
    }
    j++;
    word = (char *)malloc((j - *i + 1) * sizeof(char));
    if (word == NULL)
        return(NULL);
    copy_string(word, s + *i, j - *i);
    *i = j;
    return(word);
}

char *single_quote(const char *s, int *i)
{
    char *word;
    int j;
    
    j = *i + 1;
    while (s[j] != 39)
    {
        if (s[j] == '\0')
            return(NULL);
        j++;
    }
    word = (char *)malloc((j - (*i + 1) + 1) * sizeof(char));
    if (word == NULL)
        return(NULL);
    copy_string(word, s + *i + 1, j - *i - 1);
    *i = j + 1;
    return(word);
}

char *double_quote(const char *s, int *i)
{
    char *word;
    int j;
    
    j = *i + 1;
    while (s[j] != 34)
    {
        if (s[j] == '\0')
            return(NULL);
        j++;
    }
    word = (char *)malloc((j - (*i + 1) + 1) * sizeof(char));
    if (word == NULL)
        return(NULL);
    copy_string(word, s + *i + 1, j - *i - 1);
    *i = j + 1;
    return(word);
}

char *space(const char *s, int *i)
{
    char *word;
    int j;
    int k;
    
    k = 0;
    j = *i;
    while (s[j] != 32 && s[j] != 60 && s[j] != 62 && s[j] != '\0')
    {
        if (s[j] == 34)
        {
            j++;
            while (s[j] != 34)
            {
                if (s[j] == '\0')
                    return(NULL);
                j++;
            }
            k = k + 2;
        }
        if (s[j] == 39)
        {
            j++;
            while (s[j] != 39)
            {
                if (s[j] == '\0')
                    return(NULL);
                j++;
            }
            k = k + 2;
        }
        j++;
    }
    word = (char *)malloc((j - *i + 1 - k) * sizeof(char));
    if (word == NULL)
        return(NULL);
    copy_string_mod(word, s + *i, j - *i);
    *i = j;
    return(word);
}
