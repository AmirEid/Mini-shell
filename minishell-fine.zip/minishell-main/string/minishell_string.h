/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell_string.h                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 11:45:34 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 11:45:41 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_STRING_H
# define MINISHELL_STRING_H

char    **split_string(const char *s, t_env_var *env);
char    *space(const char *s, int *i);
char    *double_quote(const char *s, int *i);
char    *single_quote(const char *s, int *i);
char    *less(const char *s, int *i);
char    *grate(const char *s, int *i);
char    **free_string(char	**dest, size_t j);
char    *copy_string(char *dest, const char *src, size_t n);
char    *copy_string_mod(char *dest, const char *src, size_t n);
char    *sub_env_var(char *s, t_env_var *env);
int     count_env_var(const char *s, t_env_var *env);
int     search_env_var(const char *s, t_env_var *env);
char    *new_string(char *s, int z, t_env_var *env);
int     copy_env_var(const char *s, char *dest ,t_env_var *env, size_t *j);

#endif
