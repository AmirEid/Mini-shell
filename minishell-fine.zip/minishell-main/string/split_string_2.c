/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   split_string_2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/05/11 19:40:26 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

char    *copy_string_mod(char *dest, const char *src, size_t n)
{
    size_t j = 0;
    size_t z = 0;

    while (j < n && src[j] != '\0')
    {
        if (src[j] == 34)
        {
            j++;
            while (src[j] != 34)
            {
                dest[z] = src[j];
                z++;
                j++;
            }
            j++;
        }
        else if (src[j] == 39)
        {
            j++;
            while (src[j] != 39)
            {
                dest[z] = src[j];
                z++;
                j++;
            }
            j++;
        }
        else
        {
            dest[z] = src[j];
            z++;
            j++;
        }
    }
    dest[z] = '\0';
    return dest;
}

char *copy_string(char *dest, const char *src, size_t n)
{
    size_t j = 0;

    while (j < n && src[j] != '\0')
    {
        dest[j] = src[j];
        j++;
    }
    dest[j] = '\0';
    return dest;
}

char	**free_string(char	**dest, size_t j)
{
	size_t	i;

	i = 0;
	while (i <= j)
	{
		free(dest[i]);
		i++;
	}
	free(dest);
	return (NULL);
}
