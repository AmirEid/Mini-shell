/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   new_string.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nspinell <nspinell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/11 16:04:47 by nspinell          #+#    #+#             */
/*   Updated: 2024/06/14 17:41:15 by nspinell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int copy_env_var(const char *s, char *dest ,t_env_var *env, size_t *j)
{
    int i;
    char *c;
    size_t z;

    i = 0;
    while (ft_isenvvar(s[i]) == 1)
        i++;
    c = (char *)malloc((i + 1) * sizeof(char));
    if (c == NULL)
        return (-1);
    copy_string(c, s, i);
    while (env != NULL)
    {
        if (ft_strcmp(c, env->name) == 0)
        {
            z = 0;
            while (z < ft_strlen(env->value))
            {
                dest[*j] = env->value[z];
                z++;
                (*j)++;
            }
            free(c);
            return (0);
        }
        env = env->next;
    }
    free(c);
    return (0);
}

char *new_string(char *s, int z, t_env_var *env)
{
    size_t i;
    int j;
    int res;
    char *new;
    char *global;
    int k;

    i = 0;
    j = 0;
    new = (char *)malloc((z + 1) * sizeof(char));
    if (new == NULL)
        return (NULL);
    while (i < (size_t)z && s[j] != '\0')
    {
        if (s[j] == '$')
        {
            j++;
            if (s[j] == '?')
            {
                j++;
                global = ft_itoa(global_exit);
                if (global == NULL)
                {
                    free(new);
                    return (NULL);
                }
                k = 0;
                while (global[k] != '\0')
                {
                    new[i] = global[k];
                    i++;
                    k++;
                }
                free(global);
            }
            else
            {
                res = copy_env_var(s + j, new, env, &i);
                if (res == -1)
                {
                    free(new);
                    return (NULL);
                }
                while (ft_isenvvar(s[j]) == 1 && s[j] != '\0')
                    j++;
            }
        }
        else
        {
            new[i] = s[j];
            j++;
            i++;
        }
    }
    new[i] = '\0';
    free(s);
    return (new);
}
